package com.neogeo.tracking.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    // Configuration moved to OpenAPIConfig.java
}
